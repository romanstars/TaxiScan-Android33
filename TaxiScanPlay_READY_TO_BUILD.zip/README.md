# TaxiScan — повний проєкт для Google Play (з логікою сканування)

## Що реалізовано

- Сучасний UI (Material 3)
- Підписка через **Google Play Billing**
- **NotificationListenerService** — читає сповіщення Uklon / Bolt
- Парсер ціни та відстані з тексту сповіщень
- Фільтр замовлень (мін. ціна, макс. відстань, ціна/км)
- Щоденна статистика
- Skeleton **AccessibilityService** (з попередженнями для Play)
- Package: `ua.taximoney.taxiscan`
- targetSdk 35

## Структура логіки сканування

```
Order.kt                 — модель замовлення
OrderParser.kt           — витяг ціни/відстані з тексту
OrderFilter.kt           — фільтрація
DailyStats.kt            — статистика
TaxiNotificationListener — слухач сповіщень
TaxiAccessibilityService — skeleton Accessibility
```

## Як працює сканування

1. Користувач увімкнює «Доступ до сповіщень» для TaxiScan.
2. При новому сповіщенні від Uklon/Bolt парситься текст.
3. Якщо замовлення проходить фільтр — викликається callback у MainActivity.
4. Показується Toast (можна замінити на оверлей / звук).

## Важливо для Google Play

- Accessibility Service потрібно **задекларувати** в Play Console → App content.
- Опис use-case має бути чесним (допомога водію, не автоматичне прийняття).
- Не робіть приховані жести / auto-click без явної дії користувача.
- Порушення ToS Uklon/Bolt — відповідальність водія.

## Швидкий старт

1. Відкрийте в Android Studio
2. Додайте іконку (mipmap)
3. У Play Console створіть підписку `taxiscan_premium_monthly`
4. Зберіть AAB і завантажте

## Що доробити

- [ ] Підлаштувати regex у OrderParser під реальний формат сповіщень Uklon/Bolt
- [ ] Оверлей з інформацією про замовлення
- [ ] Звук / вібрація
- [ ] Збереження фільтрів у SharedPreferences
- [ ] Privacy Policy + Data safety
- [ ] Feature Graphic / скріншоти
