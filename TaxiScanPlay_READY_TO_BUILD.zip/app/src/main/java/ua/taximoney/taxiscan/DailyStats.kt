package ua.taximoney.taxiscan

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DailyStats(context: Context) {
    private val prefs = context.getSharedPreferences("taxi_stats", Context.MODE_PRIVATE)
    private val dateKey: String
        get() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    var accepted: Int
        get() = prefs.getInt("${dateKey}_accepted", 0)
        set(v) = prefs.edit().putInt("${dateKey}_accepted", v).apply()

    var skipped: Int
        get() = prefs.getInt("${dateKey}_skipped", 0)
        set(v) = prefs.edit().putInt("${dateKey}_skipped", v).apply()

    var earnings: Float
        get() = prefs.getFloat("${dateKey}_earnings", 0f)
        set(v) = prefs.edit().putFloat("${dateKey}_earnings", v).apply()

    fun addAccepted(price: Float = 0f) {
        accepted += 1
        if (price > 0) earnings += price
    }

    fun addSkipped() {
        skipped += 1
    }

    fun summary(): String = "Сьогодні: ✓ $accepted  ✗ $skipped  ₴ ${"%.0f".format(earnings)}"
}
