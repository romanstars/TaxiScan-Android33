package ua.taximoney.taxiscan

import java.util.regex.Pattern

/**
 * Парсер тексту сповіщень Uklon / Bolt.
 * Регулярні вирази потрібно підлаштувати під актуальний формат сповіщень.
 */
object OrderParser {

    // Приклади: "150 грн", "150₴", "₴150", "150.00 UAH"
    private val pricePattern = Pattern.compile(
        "(?:₴|грн|UAH|uah)?\\s*(\\d+[.,]?\\d*)\\s*(?:₴|грн|UAH|uah)?",
        Pattern.CASE_INSENSITIVE
    )

    // Приклади: "3.2 км", "3,2 km", "3.2км"
    private val distancePattern = Pattern.compile(
        "(\\d+[.,]?\\d*)\\s*(?:км|km)",
        Pattern.CASE_INSENSITIVE
    )

    fun parse(text: String, service: Order.ServiceType): Order {
        val price = extractPrice(text)
        val distance = extractDistance(text)
        return Order(
            service = service,
            price = price,
            distanceKm = distance,
            rawText = text
        )
    }

    private fun extractPrice(text: String): Double {
        val m = pricePattern.matcher(text.replace('\u00A0', ' '))
        var best = 0.0
        while (m.find()) {
            val v = m.group(1)?.replace(',', '.')?.toDoubleOrNull() ?: continue
            // Беремо найбільше правдоподібне значення в діапазоні замовлення
            if (v in 20.0..5000.0 && v > best) best = v
        }
        return best
    }

    private fun extractDistance(text: String): Double {
        val m = distancePattern.matcher(text)
        if (m.find()) {
            return m.group(1)?.replace(',', '.')?.toDoubleOrNull() ?: 0.0
        }
        return 0.0
    }

    fun detectService(packageName: String): Order.ServiceType {
        return when {
            packageName.contains("uklon", ignoreCase = true) -> Order.ServiceType.UKLON
            packageName.contains("bolt", ignoreCase = true) ||
            packageName.contains("taxify", ignoreCase = true) -> Order.ServiceType.BOLT
            else -> Order.ServiceType.UNKNOWN
        }
    }
}
