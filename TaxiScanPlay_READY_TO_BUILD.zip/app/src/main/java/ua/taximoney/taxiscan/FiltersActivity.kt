package ua.taximoney.taxiscan

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText

class FiltersActivity : AppCompatActivity() {

    private lateinit var switchEnabled: MaterialSwitch
    private lateinit var etMinPrice: TextInputEditText
    private lateinit var etMaxDistance: TextInputEditText
    private lateinit var etMinPricePerKm: TextInputEditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filters)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        switchEnabled = findViewById(R.id.switchFilterEnabled)
        etMinPrice = findViewById(R.id.etMinPrice)
        etMaxDistance = findViewById(R.id.etMaxDistance)
        etMinPricePerKm = findViewById(R.id.etMinPricePerKm)

        val filter = FilterPrefs.load(this)
        switchEnabled.isChecked = filter.enabled
        etMinPrice.setText(filter.minPrice.toInt().toString())
        etMaxDistance.setText(filter.maxDistanceKm.toInt().toString())
        etMinPricePerKm.setText(filter.minPricePerKm.toInt().toString())

        findViewById<MaterialButton>(R.id.btnSaveFilters).setOnClickListener {
            save()
        }
    }

    private fun save() {
        val filter = OrderFilter(
            minPrice = etMinPrice.text.toString().toDoubleOrNull() ?: 0.0,
            maxDistanceKm = etMaxDistance.text.toString().toDoubleOrNull() ?: 50.0,
            minPricePerKm = etMinPricePerKm.text.toString().toDoubleOrNull() ?: 0.0,
            enabled = switchEnabled.isChecked
        )
        FilterPrefs.save(this, filter)
        Toast.makeText(this, "Фільтри збережено", Toast.LENGTH_SHORT).show()
        finish()
    }
}
