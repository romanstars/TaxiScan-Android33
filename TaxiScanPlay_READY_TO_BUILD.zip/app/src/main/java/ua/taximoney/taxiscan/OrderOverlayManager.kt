package ua.taximoney.taxiscan

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.button.MaterialButton

/**
 * Показує плаваюче вікно з інформацією про нове замовлення.
 * Потрібен дозвіл SYSTEM_ALERT_WINDOW.
 */
class OrderOverlayManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: View? = null
    private var currentOrder: Order? = null

    var onAccept: ((Order) -> Unit)? = null
    var onSkip: ((Order) -> Unit)? = null

    fun canDrawOverlays(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else true
    }

    fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    fun show(order: Order) {
        if (!canDrawOverlays()) {
            Toast.makeText(context, "Увімкніть дозвіл на оверлей", Toast.LENGTH_LONG).show()
            requestOverlayPermission()
            return
        }

        hide() // прибрати попередній
        currentOrder = order

        val view = LayoutInflater.from(context).inflate(R.layout.overlay_order, null)
        overlayView = view

        view.findViewById<TextView>(R.id.tvOverlayService).text = order.service.name
        view.findViewById<TextView>(R.id.tvOverlayPrice).text =
            if (order.price > 0) "${order.price.toInt()} грн" else "—"
        view.findViewById<TextView>(R.id.tvOverlayDistance).text =
            if (order.distanceKm > 0) "${"%.1f".format(order.distanceKm)} км" else ""
        view.findViewById<TextView>(R.id.tvOverlayRaw).text = order.rawText.take(120)

        view.findViewById<TextView>(R.id.tvOverlayClose).setOnClickListener { hide() }

        view.findViewById<MaterialButton>(R.id.btnOverlaySkip).setOnClickListener {
            currentOrder?.let { onSkip?.invoke(it) }
            hide()
        }

        view.findViewById<MaterialButton>(R.id.btnOverlayAccept).setOnClickListener {
            currentOrder?.let { onAccept?.invoke(it) }
            hide()
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 120
            x = 0
            width = WindowManager.LayoutParams.MATCH_PARENT
        }

        // Перетягування
        var initialY = 0
        var initialTouchY = 0f
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialY = params.y
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(view, params)
                    true
                }
                else -> false
            }
        }

        try {
            windowManager.addView(view, params)
        } catch (e: Exception) {
            Toast.makeText(context, "Не вдалося показати оверлей: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun hide() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {}
        }
        overlayView = null
        currentOrder = null
    }
}
