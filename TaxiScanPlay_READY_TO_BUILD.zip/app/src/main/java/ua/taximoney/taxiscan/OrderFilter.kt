package ua.taximoney.taxiscan

data class OrderFilter(
    var minPrice: Double = 0.0,
    var maxDistanceKm: Double = 50.0,
    var minPricePerKm: Double = 0.0,
    var enabled: Boolean = true
) {
    fun matches(order: Order): Boolean {
        if (!enabled) return true
        if (order.price > 0 && order.price < minPrice) return false
        if (order.distanceKm > 0 && order.distanceKm > maxDistanceKm) return false
        if (order.distanceKm > 0 && order.price > 0) {
            val perKm = order.price / order.distanceKm
            if (perKm < minPricePerKm) return false
        }
        return true
    }
}
