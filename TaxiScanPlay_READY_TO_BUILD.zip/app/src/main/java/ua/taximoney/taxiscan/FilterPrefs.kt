package ua.taximoney.taxiscan

import android.content.Context

object FilterPrefs {
    private const val PREFS = "filter_prefs"

    fun load(context: Context): OrderFilter {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return OrderFilter(
            minPrice = p.getFloat("min_price", 80f).toDouble(),
            maxDistanceKm = p.getFloat("max_distance", 20f).toDouble(),
            minPricePerKm = p.getFloat("min_price_per_km", 8f).toDouble(),
            enabled = p.getBoolean("enabled", true)
        )
    }

    fun save(context: Context, filter: OrderFilter) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat("min_price", filter.minPrice.toFloat())
            .putFloat("max_distance", filter.maxDistanceKm.toFloat())
            .putFloat("min_price_per_km", filter.minPricePerKm.toFloat())
            .putBoolean("enabled", filter.enabled)
            .apply()
        TaxiNotificationListener.filter = filter
    }
}
