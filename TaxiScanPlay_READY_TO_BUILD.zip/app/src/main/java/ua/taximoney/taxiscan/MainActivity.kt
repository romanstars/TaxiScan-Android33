package ua.taximoney.taxiscan

import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.media.RingtoneManager
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView

class MainActivity : AppCompatActivity() {

    private lateinit var tvSubTitle: TextView
    private lateinit var tvSubStatus: TextView
    private lateinit var tvUklonStatus: TextView
    private lateinit var tvBoltStatus: TextView
    private lateinit var tvFiltersSub: TextView
    private lateinit var stats: DailyStats
    private lateinit var overlayManager: OrderOverlayManager
    private var isSubscribed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        stats = DailyStats(this)
        overlayManager = OrderOverlayManager(this)

        overlayManager.onAccept = { order ->
            stats.addAccepted(order.price.toFloat())
            Toast.makeText(this, "Прийнято: ${order.price.toInt()} грн", Toast.LENGTH_SHORT).show()
        }
        overlayManager.onSkip = {
            stats.addSkipped()
            Toast.makeText(this, "Пропущено", Toast.LENGTH_SHORT).show()
        }

        tvSubTitle = findViewById(R.id.tvSubTitle)
        tvSubStatus = findViewById(R.id.tvSubStatus)
        tvUklonStatus = findViewById(R.id.tvUklonStatus)
        tvBoltStatus = findViewById(R.id.tvBoltStatus)
        tvFiltersSub = findViewById(R.id.tvFiltersSub)

        findViewById<MaterialCardView>(R.id.cardSubscription).setOnClickListener {
            startActivity(Intent(this, SubscriptionActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardUklon).setOnClickListener {
            checkPermissions()
        }

        findViewById<MaterialCardView>(R.id.cardBolt).setOnClickListener {
            checkPermissions()
        }

        findViewById<MaterialCardView>(R.id.cardFilters).setOnClickListener {
            startActivity(Intent(this, FiltersActivity::class.java))
        }

        findViewById<android.view.View>(R.id.itemPrice).setOnClickListener {
            startActivity(Intent(this, FiltersActivity::class.java))
        }

        findViewById<TextView>(R.id.tvJoinGroup).setOnClickListener {
            Toast.makeText(this, "Відкрийте посилання на групу", Toast.LENGTH_SHORT).show()
        }

        TaxiNotificationListener.listener = { order ->
            runOnUiThread {
                playNotificationSound()
                overlayManager.show(order)
            }
        }

        // Завантажити збережені фільтри
        TaxiNotificationListener.filter = FilterPrefs.load(this)
    }

    override fun onResume() {
        super.onResume()
        updateSubscriptionCard()
        updateServiceStatus()
        val f = FilterPrefs.load(this)
        TaxiNotificationListener.filter = f
        updateFiltersSubtitle(f)
    }

    private fun updateFiltersSubtitle(f: OrderFilter) {
        tvFiltersSub.text = if (f.enabled) {
            "від ${f.minPrice.toInt()} грн • до ${f.maxDistanceKm.toInt()} км"
        } else {
            "Вимкнено"
        }
    }

    private fun playNotificationSound() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            RingtoneManager.getRingtone(this, uri)?.play()
        } catch (_: Exception) {}
    }

    private fun updateSubscriptionCard() {
        if (isSubscribed) {
            tvSubTitle.text = getString(R.string.subscription_active)
            tvSubStatus.text = "Підписка діє"
            tvSubStatus.setTextColor(Color.parseColor("#32BB78"))
        } else {
            tvSubTitle.text = getString(R.string.subscription_title)
            tvSubStatus.text = getString(R.string.subscription_inactive) + " • Натисніть"
            tvSubStatus.setTextColor(Color.parseColor("#B0BEC5"))
        }
    }

    private fun updateServiceStatus() {
        val notifEnabled = isNotificationListenerEnabled()
        val overlayOk = overlayManager.canDrawOverlays()
        val status = when {
            notifEnabled && overlayOk -> "Активний ✓"
            notifEnabled -> "Сповіщення ✓"
            else -> "Налаштування"
        }
        tvUklonStatus.text = status
        tvBoltStatus.text = status
        if (notifEnabled) {
            tvUklonStatus.setTextColor(Color.parseColor("#32BB78"))
            tvBoltStatus.setTextColor(Color.parseColor("#32BB78"))
        }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        if (flat.isNullOrEmpty()) return false
        return flat.split(":").any {
            ComponentName.unflattenFromString(it)?.packageName == packageName
        }
    }

    private fun checkPermissions() {
        val needNotif = !isNotificationListenerEnabled()
        val needOverlay = !overlayManager.canDrawOverlays()
        if (!needNotif && !needOverlay) {
            Toast.makeText(this, "Усі дозволи увімкнено", Toast.LENGTH_SHORT).show()
            return
        }
        val msg = buildString {
            if (needNotif) appendLine("• Доступ до сповіщень")
            if (needOverlay) appendLine("• Відображення поверх інших вікон")
        }
        AlertDialog.Builder(this)
            .setTitle("Потрібні дозволи")
            .setMessage("Для роботи сканування увімкніть:\n$msg")
            .setPositiveButton("Налаштування") { _, _ ->
                if (needNotif) startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                else overlayManager.requestOverlayPermission()
            }
            .setNegativeButton("Скасувати", null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        TaxiNotificationListener.listener = null
        overlayManager.hide()
    }
}
