package ua.taximoney.taxiscan

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * Skeleton Accessibility Service.
 *
 * ВАЖЛИВО для Google Play:
 * - Використовуйте ТІЛЬКИ для заявленого use-case (допомога водію).
 * - Обов'язково заповніть форму Accessibility в Play Console.
 * - Не робіть приховані жести / авто-кліки без явної дії користувача.
 * - Порушення ToS Uklon/Bolt може призвести до блокування акаунта водія.
 */
class TaxiAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "TaxiAccessibility"
        var instance: TaxiAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 100
        }
        serviceInfo = info
        Log.d(TAG, "Accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        // Тут можна аналізувати UI інших додатків.
        // Реалізуйте обережно і тільки для заявленого функціоналу.
        val pkg = event.packageName?.toString() ?: return
        if (!pkg.contains("uklon", true) && !pkg.contains("bolt", true) &&
            !pkg.contains("taxify", true)) return

        // Приклад: логування зміни вікна
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            Log.d(TAG, "Window changed in $pkg")
        }
    }

    override fun onInterrupt() {
        Log.d(TAG, "Interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}
