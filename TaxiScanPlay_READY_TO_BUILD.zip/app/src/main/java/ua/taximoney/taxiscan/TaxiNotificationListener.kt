package ua.taximoney.taxiscan

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * Слухає сповіщення від Uklon і Bolt.
 * Користувач повинен вручну увімкнути доступ у Налаштування → Сповіщення → доступ до сповіщень.
 */
class TaxiNotificationListener : NotificationListenerService() {

    companion object {
        private const val TAG = "TaxiNotifListener"
        var listener: ((Order) -> Unit)? = null
        var filter: OrderFilter = OrderFilter()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val pkg = sbn.packageName ?: return
        val service = OrderParser.detectService(pkg)
        if (service == Order.ServiceType.UNKNOWN) return

        val extras = sbn.notification?.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: ""
        val full = listOf(title, text, bigText).filter { it.isNotBlank() }.joinToString("\n")

        if (full.isBlank()) return

        Log.d(TAG, "[$service] $full")

        val order = OrderParser.parse(full, service)
        if (filter.matches(order)) {
            listener?.invoke(order)
        }
    }

    override fun onListenerConnected() {
        Log.d(TAG, "Notification listener connected")
    }

    override fun onListenerDisconnected() {
        Log.d(TAG, "Notification listener disconnected")
    }
}
