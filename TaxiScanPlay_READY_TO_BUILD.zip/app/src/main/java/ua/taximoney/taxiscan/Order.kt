package ua.taximoney.taxiscan

data class Order(
    val service: ServiceType,
    val price: Double = 0.0,
    val distanceKm: Double = 0.0,
    val addressFrom: String = "",
    val addressTo: String = "",
    val rawText: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    enum class ServiceType { UKLON, BOLT, UNKNOWN }
}
